<?php $__env->startSection('content'); ?>
    <style type="text/css">
        fieldset.scheduler-border {
            width: inherit; /* Or auto */
            padding: 0 10px; /* To give a bit of padding on the left and right */
            border-bottom: none;
        }
    </style>

    <div class="col-md-12">
        <div class="col-md-8  ml-auto mr-auto">
            2 id agreement
        </div>
    </div>

    
    


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.marketing_enno', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>