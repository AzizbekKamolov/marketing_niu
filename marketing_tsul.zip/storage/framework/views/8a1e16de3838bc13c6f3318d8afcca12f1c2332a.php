<?php $__env->startSection('content'); ?>
    <section class="section my-4 my-sm-2 my-md-2 my-lg-2 my-xl-2">
        <div class="container">

            <div class="col-12 d-flex text-center">

                <div class="container-fluid">
                    Shartnoma hali tayyor emas
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        // $('button[data-toggle="modal"]').click(function(){
        //     var target = $(this).attr('data-target');
        //     var modal = $(target);
        //     var myModal = new bootstrap.Modal(modal)
        //     modal.modal('show')
        // })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.marketing2021', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>