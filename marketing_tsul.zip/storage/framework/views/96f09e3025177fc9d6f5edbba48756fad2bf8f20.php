<footer id="footer">
    <div class="footer-top">
        <div class="container">
            <div class="row">

                <div class="col-lg-3 col-md-6 footer-contact">
                    <h3>TSUL</h3>
                    <p>


                        <strong>Tel:</strong>(+998 71) 233-66-36  (ichki 1081)<br>
                        <strong>Email:</strong> info@tsul.uz<br>
                    </p>
                </div>






























            </div>
        </div>
    </div>

    <div class="container footer-bottom clearfix">
        <div class="copyright">
            &copy; Copyright <strong><span>TSUL</span></strong>. All Rights Reserved
        </div>

    </div>

</footer>
