<?php

use Faker\Generator as Faker;

$factory->define(Test\GettingAgreement::class, function (Faker $faker) {
    return [
        //
    ];
});
