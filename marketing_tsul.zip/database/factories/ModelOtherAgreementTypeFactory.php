<?php

use Faker\Generator as Faker;

$factory->define(Test\Model\OtherAgreementType::class, function (Faker $faker) {
    return [
        //
    ];
});
