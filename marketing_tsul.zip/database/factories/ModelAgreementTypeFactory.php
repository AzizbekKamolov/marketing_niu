<?php

use Faker\Generator as Faker;

$factory->define(Test\Model\AgreementType::class, function (Faker $faker) {
    return [
        //
    ];
});
