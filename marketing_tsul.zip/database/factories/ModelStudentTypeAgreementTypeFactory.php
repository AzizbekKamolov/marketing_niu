<?php

use Faker\Generator as Faker;

$factory->define(Test\Model\StudentTypeAgreementType::class, function (Faker $faker) {
    return [
        //
    ];
});
