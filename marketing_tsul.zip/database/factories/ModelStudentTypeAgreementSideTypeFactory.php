<?php

use Faker\Generator as Faker;

$factory->define(Test\Model\StudentTypeAgreementSideType::class, function (Faker $faker) {
    return [
        //
    ];
});
