<?php

use Faker\Generator as Faker;

$factory->define(Test\Model\AgreementSideType::class, function (Faker $faker) {
    return [
        //
    ];
});
