<?php

use Faker\Generator as Faker;

$factory->define(Test\StudentOtherAgreementAccess::class, function (Faker $faker) {
    return [
        //
    ];
});
