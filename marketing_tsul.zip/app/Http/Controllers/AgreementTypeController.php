<?php

namespace Test\Http\Controllers;

use Test\Model\AgreementType;
use Illuminate\Http\Request;

class AgreementTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \Test\Model\AgreementType  $agreementType
     * @return \Illuminate\Http\Response
     */
    public function show(AgreementType $agreementType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \Test\Model\AgreementType  $agreementType
     * @return \Illuminate\Http\Response
     */
    public function edit(AgreementType $agreementType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Test\Model\AgreementType  $agreementType
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AgreementType $agreementType)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \Test\Model\AgreementType  $agreementType
     * @return \Illuminate\Http\Response
     */
    public function destroy(AgreementType $agreementType)
    {
        //
    }
}
