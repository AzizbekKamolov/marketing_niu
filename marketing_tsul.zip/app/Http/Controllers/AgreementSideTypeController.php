<?php

namespace Test\Http\Controllers;

use Test\Model\AgreementSideType;
use Illuminate\Http\Request;

class AgreementSideTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \Test\Model\AgreementSideType  $agreementSideType
     * @return \Illuminate\Http\Response
     */
    public function show(AgreementSideType $agreementSideType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \Test\Model\AgreementSideType  $agreementSideType
     * @return \Illuminate\Http\Response
     */
    public function edit(AgreementSideType $agreementSideType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Test\Model\AgreementSideType  $agreementSideType
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AgreementSideType $agreementSideType)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \Test\Model\AgreementSideType  $agreementSideType
     * @return \Illuminate\Http\Response
     */
    public function destroy(AgreementSideType $agreementSideType)
    {
        //
    }
}
