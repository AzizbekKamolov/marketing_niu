<?php

namespace Test\Model;

use Illuminate\Database\Eloquent\Model;
use Test\User;

class EduType extends Model
{
    protected $table='edu_types';

}
