<?php

namespace Test\Model;

use Illuminate\Database\Eloquent\Model;

class Spec extends Model
{
    protected $table="tb_mvdir";
}
