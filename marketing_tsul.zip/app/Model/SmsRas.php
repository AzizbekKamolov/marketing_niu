<?php

namespace Test\Model;

use Illuminate\Database\Eloquent\Model;
use Test\User;

class SmsRas extends Model
{
    protected $table = 'sms_ras';
    public $timestamps = false;
}
