<?php

namespace Test\Model;

use Illuminate\Database\Eloquent\Model;

class AgreementType extends Model
{
    //
}
