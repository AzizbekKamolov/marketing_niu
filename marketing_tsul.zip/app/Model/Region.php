<?php

namespace Test\Model;

use Illuminate\Database\Eloquent\Model;
use Test\User;

class Region extends Model
{
    protected $table='test_sys_region';
  

    
}
