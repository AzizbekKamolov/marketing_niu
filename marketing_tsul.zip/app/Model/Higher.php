<?php

namespace Test\Model;

use Illuminate\Database\Eloquent\Model;

class Higher extends Model
{
    protected $table="tb_universityhave";
}
