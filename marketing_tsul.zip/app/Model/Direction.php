<?php

namespace Test\Model;

use Illuminate\Database\Eloquent\Model;
use Test\User;

class Direction extends Model
{
    protected $table='dir';
  

    
}
