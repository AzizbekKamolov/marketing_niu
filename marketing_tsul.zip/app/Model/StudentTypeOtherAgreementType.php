<?php

namespace Test\Model;

use Illuminate\Database\Eloquent\Model;

class StudentTypeOtherAgreementType extends Model
{
    //
}
