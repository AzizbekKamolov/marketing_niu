<?php

namespace Test\Model;

use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
    protected $table = "sp_country";
}
