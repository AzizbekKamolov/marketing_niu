<?php

namespace Test\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use Test\Model\Direction;
use Test\Model\Lang;


class Rrr extends Model
{
    protected $table = "rrrrrrrr2";
    public $timestamps = false;



}