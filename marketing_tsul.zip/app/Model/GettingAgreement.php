<?php

namespace Test\Model;

use Illuminate\Database\Eloquent\Model;

class GettingAgreement extends Model
{
    protected $table = 'getting_agreements';
}
