<?php

namespace Test\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use Test\Model\Amount;
use Test\Model\Direction;
use Test\Model\Lang;

class Session extends Model
{
    protected $table = "sessions";


    



}