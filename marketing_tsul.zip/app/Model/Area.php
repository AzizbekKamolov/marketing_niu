<?php

namespace Test\Model;

use Illuminate\Database\Eloquent\Model;
use Test\User;

class Area extends Model
{
    protected $table='test_sys_area';
  

    
}
