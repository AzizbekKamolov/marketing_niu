<?php

namespace Test\Model;

use Illuminate\Database\Eloquent\Model;
use Test\User;
use Test\Model\Amount;

class PassedBall extends Model
{
    protected  $table = 'passed_ball';

}
