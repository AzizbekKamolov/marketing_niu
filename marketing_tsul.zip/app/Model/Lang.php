<?php

namespace Test\Model;

use Illuminate\Database\Eloquent\Model;
use Test\User;

class Lang extends Model
{
    protected $table='lang';
  

    
}
