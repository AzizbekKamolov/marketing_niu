<?php

namespace Test\Model;

use Illuminate\Database\Eloquent\Model;
use Test\User;

class LyceumAmount extends Model
{
    protected $table='kollej_amounts';
}
