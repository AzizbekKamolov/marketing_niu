<?php

namespace Test\Model;

use Illuminate\Database\Eloquent\Model;

class StudyLanguage extends Model
{
    protected $table = "tb_llang";
}
