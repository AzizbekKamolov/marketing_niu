@extends('layouts.marketing_enno')
@section('content')
<style type="text/css">
    .flex{
      display: flex;
      justify-content: space-between;
    }
    p{
      display: block;
    }
    .bold{
      font-size: 22px ;
      font-weight: bold;
    }
  </style>
<div class=" p-5">
  <div class="col-md-12">
    <div class="col-md-6 ml-auto mr-auto text-center bold">
    <h5>
      Mutaxassisni qoʻshma ta’lim dasturi boʻyicha tayorlash haqida ikki tomonlama
      KONTRAKT
      (stipendiyasiz shaklda)
    </h5>
  </div>
  </div>
  <div class="col-md-12">
    <div class="col-md-6 ml-auto mr-auto text-center">
      ID: {{ $data->id_code }}
    </div>
    <div class="col-md-6 ml-auto mr-auto text-center">
      № _________
    </div>
  </div>

<div class="col-md-12 flex"  >
  <div>
    Toshkent sh.         
  </div>
  <div>
     2020 yil «____»____________
  </div>
</div>

                                                                           
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
Toshkent davlat yuridik universiteti (keyingi oʻrinlarda – Ta’lim muassasasi) nomidan Ustavga asosan ish yurituvchi rektor Xakimov Raxim Rasuljonovich bir tomondan, va {{ date('d-m-Y' , strtotime($data->birthday)) }} yilda tugʻilgan {{ $data->fio() }}
                                                                                                                
(keyingi oʻrinlarda – Talaba) ikkinchi tomondan (birgalikda – Tomonlar) “Yurisprudensiya” ta’lim yoʻnalishi doirasida M.S.Narikbayev nomidagi QOZGYU (Qozogʻiston Respublikasi) (keyingi oʻrinlarda – QOZGYU universiteti) bilan tuzilgan qoʻshma ta’lim dasturi boʻyicha talabani bakalavriat bosqichida oʻqitish maqsadida mazkur kontraktni (keyingi oʻrinlarda – Kontrakt) Oʻzbekiston Respublikasi Prezidentining 2020-yil 29-apreldagi 
PF–5987-son Farmoni, 2019-yil 11-iyuldagi PQ–4391-son qarori, Oʻzbekiston Respublikasi Vazirlar Mahkamasining 2019 yil 3 dekabrdagi 967-son qarori hamda Oliy va oʻrta maxsus, kasb-hunar ta’limi muassasalarida oʻqitishning toʻlov-kontrakt shakli va undan tushgan mablagʻlarni taqsimlash tartibi toʻgʻrisidagi nizomga (roʻyxat raqami 2431, 2013 yil 26 fevral) muvofiq tuzdilar:

<div class="col-md-12">
    <div class="col-md-6 ml-auto mr-auto text-center bold">
    <h5>
      1. KONTRAKT PREDMETI
    </h5>
  </div>
</div>


<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

  1.1. Mazkur Kontraktga asosan Ta’lim muassasasi Talabani 2022/2023 oʻquv yili hamda 2023/2024 oʻquv yilining bahorgi semestri  davomida belgilangan ta’lim standartlari va oʻquv dasturlariga muvofiq oʻqitadi, Talaba esa Kontraktning 2-bobida koʻrsatilgan tartib va miqdordagi toʻlovni amalga oshiradi hamda Ta’lim muassasasida belgilangan tartibga muvofiq ta‘lim olish majburiyatini oladi.
</p>

<div class="col-md-12">
    <div class="col-md-6 ml-auto mr-auto text-center bold">
    <h5>
      2.  HISOB-KITOB QILISH TARTIBI
    </h5>
  </div>
</div>


<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  2.1. QOZGYU universiteti bilan tuzilgan qoʻshma ta’lim dasturi boʻyicha Talaba 2022/2023 oʻquv yili hamda 2023/2024 oʻquv yilining bahorgi semestri davomida Ta’lim muassasasida ta’lim olishini inobatga olgan holda Kontrakt boʻyicha toʻlovlar miqdori va muddatlari quyidagicha belgilandi:
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
2022/2023 oʻquv yili uchun toʻlov 139 (bir yuz oʻttiz toʻqqiz) bazaviy hisoblash miqdorini tashkil qiladi va quyidagi muddatlarda Ta’lim muassasasiga toʻlanadi:
  
</p>
<p style="padding-left: 100px;">
  2022-yil 15-oktyabgacha – 34,75 (oʻttiz toʻrtu, yetmish besh) bazaviy hisoblash miqdori;<br>
2022-yil 15-dekabrgacha – 34,75 (oʻttiz toʻrtu, yetmish besh) bazaviy hisoblash miqdori;<br>
2023-yil 15-fevralgacha – 34,75 (oʻttiz toʻrtu, yetmish besh) bazaviy hisoblash miqdori;<br>
2023-yil 01-maygacha – 34,75 (oʻttiz toʻrtu, yetmish besh) bazaviy hisoblash miqdori.<br>

</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
2.1.2. 2023/2024 oʻquv yilining bahorgi semestri uchun toʻlov 93 (toʻqson uch) bazaviy hisoblash miqdorini tashkil qiladi va quyidagi muddatlarda toʻlanadi:
  
</p>
<p style="padding-left: 100px;">
  2024-yil 15-fevralgacha – 46,5 (qirq oltiyu, besh) bazaviy hisoblash miqdori;<br>
2024-yil 01-maygacha – 46,5 (qirq oltiyu, besh) bazaviy hisoblash miqdori.<br>

</p>

<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
2.2. Kontraktni amal qilish davrida bazaviy hisoblash miqdori oʻzgargan taqdirda Kontrakt boʻyicha tegishli ravishda oʻzgargan toʻlov miqdori oʻquv yilining keyingi davrida uchun toʻlanadi.
  
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
2.3. QOZGYU universiteti bilan tuzilgan qoʻshma ta’lim dasturi boʻyicha Kontraktni stipendiyasiz shakldan stipendiyali shakliga oʻtishga yoʻl qoʻyilmaydi.
  
</p>

<div class="col-md-12">
    <div class="col-md-6 ml-auto mr-auto text-center bold">
    <h5>
      3. TOMONLARNING HUQUQ VA MAJBURIYATLARI
    </h5>
  </div>
</div>


<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.1. Ta’lim muassasasining huquqlari:
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.1.1. Talabadan shartnomaviy majburiyatlari bajarilishini, shu jumladan Ta’lim muassasasining ichki hujjatlarida belgilangan qoidalarga rioya qilishni, oʻquv mashgʻulotlarida muntazam qatnashishni, Kontrakt boʻyicha toʻlovlarni oʻz vaqtida amalga oshirishni talab qilish.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.1.2. Ta’lim muassasasining ichki hujjatlarida belgilangan qoidalarga rioya qilmagan, bir semestr davomida darslarni uzrli sabablarsiz 74 soatdan ortiq qoldirgan yoki oʻqitish uchun belgilangan miqdordagi toʻlovni oʻz vaqtida amalga oshirmagan Talabaga nisbatan belgilangan tartibda talabalar safidan chetlashtirish, tegishli kursda qoldirish yoki boshqa choralarni qoʻllash.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.1.3. Talaba Ta’lim muassasasining ichki hujjatlarida belgilangan qoidalarni qoʻpol ravishda buzgan, xususan huquqbuzarlik sodir etgan hollarda Kontraktni bir tomonlama bekor qilish. 
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.1.4. Istisno tariqasida Kontrakt boʻyicha toʻlov muddatlarini uzaytirish (Ta’lim muassasasining buyrugʻi orqali).
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.2. Ta’lim muassasasining majburiyatlari:
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.2.1. Oʻqitish uchun Oʻzbekiston Respublikasining “Ta’lim toʻgʻrisida”gi Qonuni va Kadrlar tayyorlash milliy dasturiga muvofiq Ta’lim muassasasi Ustavi va boshqa ichki hujjatlarida nazarda tutilgan zarur shart-sharoitlarni yaratadi.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.2.2. Talabalarning qonun hujjatlarida belgilangan huquqlarining bajarilishini ta’minlaydi.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.2.3. Talabani tasdiqlangan oʻquv reja va dasturlarga muvofiq davlat standarti talablari darajasida oʻqitadi.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.2.4. Talaba QOZGYU universiteti bilan tuzilgan qoʻshma ta’lim dasturi boʻyicha bakalavriat yoʻnalishini muvaffaqiyatli tamomlaganda belgilangan tartibda diplom beradi.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.2.5. QOZGYU universitetining xatiga asosan Talabani talabalar safiga kiritadi.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.3. Talabaning huquqlari:
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.3.1. Ta’lim muassasasidan shartnomaviy majburiyatlari bajarilishini talab qilish.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.3.2. Ta’lim muassasasida tasdiqlangan oʻquv reja va dasturlarga muvofiq davlat standarti talablari darajasida ta’lim olish.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.3.3. Ta’lim muassasasining Axborot-resurs markazi, sport inshooti, Wi-Fi hududlaridan foydalanish.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.3.4. Ta’lim muassasasining ta’lim jarayonlarini yaxshilashga doir takliflar berish.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.3.5. Oʻqish uchun bir yillik toʻlov summasini bir yola toʻliq toʻlash.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.4. Talabaning majburiyatlari:
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.4.1. Joriy oʻquv yili uchun belgilangan oʻqitish qiymatini Kontraktning 2-bobida koʻrsatilgan tartib va miqdorda oʻz vaqtida toʻlaydi.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.4.2. Toshkent davlat yuridik universiteti Ustavi va boshqa ichki hujjatlari talablariga qat’iy rioya qiladi.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.4.3. Oʻquv mashgʻulotlarida muntazam qatnashadi.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.4.4. Ta’lim muassasasida belgilangan tartib va doirada ta’lim oladi hamda ushbu jarayonda bilim darajasini oshirib boradi.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
3.4.5. Kontraktni imzolangandan keyin Ta’lim muassasasiga taqdim etadi. Kontrakt elektron shaklda Ta’lim muassasasining marketing.tsul.uz saytidan olingan taqdirda uning shartlari bilan tanishib, rozi boʻlgan holda bu haqda tegishli tugmani bosadi va Kontraktni yuklab oladi.
</p>


<div class="col-md-12">
    <div class="col-md-6 ml-auto mr-auto text-center bold">
    <h5>
      4. SHARTNOMANI BEKOR QILISH
    </h5>
  </div>
</div>

<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
4. Kontrakt quyidagi hollarda bekor qilinadi:
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
4.1. Tomonlarning oʻzaro roziligi bilan.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
4.2. Ta’lim muasasasining tashabbusiga koʻra Ustavi va boshqa ichki hujjatlariga muvofiq Talaba talabalar safidan chiqarilganda.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
4.3. Oʻqitish qiymati belgilangan muddat ichida toʻlanmasa (bunda, Ta’lim muassasasi Kontraktni bir tomonlama bekor qiladi, Talaba Talabalar safidan chiqariladi).
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
4.4. Talabaning tashabbusiga koʻra (yozma murojaatga asosan).
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
4.5. Kontraktning 3.1.3-bandida koʻrsatilgan hollarda (Ta’lim muassasasi tomonidan Kontraktning bir tomonlama bekor qilinishi va talabalar safidan chiqarilishi haqida Talabaga yozma xabarnoma yuborish orqali).
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
4.6. Talaba Ta’lim muasasasining talabalari safidan chiqarilganda QOZGYU universitetining talabalari safidan ham avtomatik ravishda chiqariladi, shuningdek Talaba QOZGYU universitetining talabalari safidan chiqarilganda Ta’lim muasasasining talabalari safidan avtomatik ravishda chiqariladi.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
4.7. Qonunchilikda koʻrsatilgan boshqa hollarda.
</p>

<div class="col-md-12">
    <div class="col-md-6 ml-auto mr-auto text-center bold">
    <h5>
      5. FORS-MAJOR HOLATLAR
    </h5>
  </div>
</div>

<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
5.1. Ushbu Kontraktga asosan majburiyatlarni bajarilmasligi holatlari yengib boʻlmaydigan kuchlar (fors-major) holatlar natijasida vujudga kelganda Tomonlar oʻz majburiyatlarini bajarmaslikdan qisman yoki toʻliq ozod boʻladilar.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
5.2. Yengib boʻlmaydigan kuchlar (fors-major) holatlariga Tomonlarning irodasi va faoliyatiga bogʻliq boʻlmagan tabiat hodisalari (pandemiya, zilzila, koʻchki, boʻron, qurgʻoqchilik va boshqalar) yoki ijtimoiy-iqtisodiy holatlar (urush holati, qamal, davlat manfaatlarini koʻzlab import va eksportni taqiqlash va boshqalar) sababli yuzaga kelgan sharoitlarda Tomonlarga qabul qilingan majburiyatlarni bajarish imkonini bermaydigan favqulodda, oldini olib boʻlmaydigan va kutilmagan holatlar kiradi.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
5.3. Kontrakt Tomonlaridan qaysi biri uchun majburiyatlarni yengib boʻlmaydigan kuchlar (fors-major) holatlari sababli bajarmaslik ma’lum boʻlsa, darhol ikkinchi tomonga bu xaqda 10 kun ichida ushbu holatlar harakati sababini dalillar bilan taqdim etishi lozim.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
5.4. Kontraktga asosan majburiyatlarni ijro qilish muddati ushbu yengib boʻlmaydigan kuchlar (fors-major) holatlar davom etish muddatiga qadar uzaytiriladi. Agar yengib boʻlmaydigan kuchlar (fors-major) ta’siri 30 (oʻttiz) kundan ortiqroq davom qilsa, Tomonlar tashabbusiga binoan shartnoma bekor qilinishi mumkin.
</p>

<div class="col-md-12">
    <div class="col-md-6 ml-auto mr-auto text-center bold">
    <h5>
      6. YAKUNIY QOIDALAR
      
    </h5>
  </div>
</div>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
6.1. Kontrakt bevosita Tomonlar tomonidan imzolangan paytdan e’tiboran kuchga kiradi, Kontraktning 6.2-bandida koʻrsatilgan holat bundan mustasno. 
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
6.2. Kontrakt elektron shaklda Ta’lim muassasasining marketing.tsul.uz saytida joylashtirilgan boʻlib, Talaba oʻz passport ma’lumotlarini kiritganidan soʻng uning shartlari bilan tanishib, rozi boʻlgan holda bu haqda tegishli tugmani bosadi va Kontraktni yuklab oladi. Kontrakt Talaba tomonidan yuklab olingan paytdan e’tiboran tuzilgan va kuchga kirgan hisoblanadi.
Talaba Kontrakt shartlari bilan norozi boʻlgan taqdirda uch ish kunida, biroq joriy yilning 15 oktyabga qadar murojaat qilishi mumkin. Kontraktni tuzmagan va toʻlovlarni amalga oshirmagan Talabani Ta’lim muassasasi talabalar safidan chiqarishga haqli.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
6.3. Talaba tomonidan shartnoma boʻyicha oʻqitish qiymatini toʻlashda toʻlov topshiriqnomasida shartnomaning tartib raqami va sanasi, talabaning familiyasi, ismi, sharifi hamda oʻqiyotgan kursi toʻliq koʻrsatiladi.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
6.4. Tomonlar oʻrtasida vujudga keladigan nizolar oʻzaro muzokaralar olib borish hamda talabnoma yuborish orqali hal etiladi, Kontraktning 4.2-4.6 bandlarida koʻrsatilgan holatlar bundan mustasno.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
6.5. Ta’lim muasasasida oʻqitishning modul tizimi sharoitlarida talabalar bilimini nazorat qilish tartibi va baholash mezonlari toʻgʻrisidagi nizom (roʻyxat raqami 2780, 2016 yil 22 aprel)ga muvofiq qayta oʻzlashtirish uchun belgilangan tartibda oʻquv fanlari boʻyicha kelgusi semestrning yakuniy nazorat davri boshlangunga qadar tegishli fanlar boʻyicha akademik qarzdorlikni qayta topshirish sharti bilan keyingi kurs (semestr)ga oʻtkazilgan Talabadan ushbu semestr uchun ham toʻlov undiriladi.
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
6.6. QOZGYU universiteti va Talaba oʻrtasida mutaxassisni qoʻshma ta’lim dasturi boʻyicha tayorlash haqida ikki tomonlama shartnoma(kontrakt) tuzilmagan taqdirda, mazkur Kontrakt oʻz kuchini yoʻqotadi.
</p>

<div class="col-md-12">
  <button class="tasdiq btn btn-success">
    Men , Talaba <b>{{ $data->fio() }}</b> , Toshkent davlat yuridik universitetida o'qitish uchun Kontrakt mazmuni bilan to'liq tanishdim va uning shartlariga roziman hamda shaxsiy ma`lumotlarim to'g'riligini tasdiqlayman
  </button>
</div>




</div>
<form style="display: none" method="post" id="hehe" action="{{ route('shartnoma.get_degree') }}">
               {{ csrf_field() }}
               <input type="text" readonly="true" value="{{ $data->id_code }}" name="id_code" hidden="true">
           </form>

@endsection

@section('js')

<script type="text/javascript">
   $(document).ready(function(){
    alert("dfjd");
   });
    
    
</script>
@endsection
