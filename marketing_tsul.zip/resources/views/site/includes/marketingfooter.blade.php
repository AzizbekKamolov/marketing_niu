<footer id="footer">
    <div class="footer-top">
        <div class="container">
            <div class="row">

                <div class="col-lg-3 col-md-6 footer-contact">
                    <h3>TSUL</h3>
                    <p>


                        <strong>Tel:</strong>(+998 71) 233-66-36  (ichki 1081)<br>
                        <strong>Email:</strong> info@tsul.uz<br>
                    </p>
                </div>

{{--                <div class="col-lg-3 col-md-6 footer-links">--}}
{{--                    <h4>Foydali Saytlar</h4>--}}
{{--                    <ul>--}}
{{--                        <li><i class="bx bx-chevron-right"></i> <a href="http://marketing.tsul.uz">Bosh sahifa</a></li>--}}
{{--                        <li><i class="bx bx-chevron-right"></i> <a href="https://tsul.uz">Biz haqimizda</a></li>--}}

{{--                    </ul>--}}
{{--                </div>--}}

{{--                <div class="col-lg-3 col-md-6 footer-links">--}}
{{--                    <h4>Xizmatlar</h4>--}}
{{--                    <ul>--}}
{{--                        <li><i class="bx bx-chevron-right"></i> <a href="#">Web Design</a></li>--}}
{{--                        <li><i class="bx bx-chevron-right"></i> <a href="#">Marketing</a></li>--}}
{{--                    </ul>--}}
{{--                </div>--}}

{{--                <div class="col-lg-3 col-md-6 footer-links">--}}
{{--                    <h4>Ijtimoiy tarmoqlarda</h4>--}}
{{--                    <p>Bizni kuzatib boring</p>--}}
{{--                    <div class="social-links mt-3">--}}
{{--                        <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>--}}
{{--                        <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>--}}
{{--                        <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>--}}
{{--                        <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>--}}
{{--                        <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>--}}
{{--                    </div>--}}
{{--                </div>--}}

            </div>
        </div>
    </div>

    <div class="container footer-bottom clearfix">
        <div class="copyright">
            &copy; Copyright <strong><span>TSUL</span></strong>. All Rights Reserved
        </div>

    </div>

</footer>
