@extends('layouts.admin_jamshid')

@section('content')

    <div class="container">

        <div class="row padding-30">
{{--            @if(0)--}}
            <div class="col-md-4">
                <div class="block block-success padding-top-20">
                    <div class="block-content block-success">
                        <div class="list-group">

           
                           
                        </div>
                    </div>
                </div>
            </div>

{{--            @endif--}}
<br>
 <h1>Boshqaruv paneliga xush kelibsiz!</h1>
 
        </div>
    </div>

@endsection